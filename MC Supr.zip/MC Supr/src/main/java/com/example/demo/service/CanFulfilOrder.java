package com.example.demo.service;

import com.example.demo.db.CategoryDB;
import com.example.demo.db.WarehouseDB;
import com.example.demo.exchange.Request;
import com.example.demo.model.Category;
import com.example.demo.model.Item;
import com.example.demo.model.OrderDate;
import com.example.demo.model.WareHouse;
import com.example.demo.utils.InializeDbHelper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class CanFulfilOrder {

    CategoryDB categoryDB;

    WarehouseDB warehouseDB;

    public Boolean OrderFulfilmentService(Request request, CategoryDB categoryDB, WarehouseDB warehouseDB) throws InterruptedException {
        this.warehouseDB = warehouseDB;
        this.categoryDB = categoryDB;
        List<WareHouse> wareHouseList = warehouseDB.getWareHouseList();
        List<Category> categoryList = categoryDB.getCategoryList();

        WareHouse wareHouse = new WareHouse();
        for(int i=0;i<wareHouseList.size();i++){
//            System.out.println("WareHouse ID "+ wareHouseList.get(i).getId());
//            System.out.println("Request WareHouse ID "+ request.getWarehouse_id());
            if(wareHouseList.get(i).getId().equals(request.getWarehouse_id())) {
                wareHouse = wareHouseList.get(i);
                break;
            }
        }

        LocalDate orderDate = request.getDelivery_date();
        List<Item> itemList = new ArrayList<>();

        for(int i=0;i<wareHouse.getDates().size();i++){

            OrderDate date = wareHouse.getDates().get(i);

            if(date.getDate().equals(orderDate)) {
                itemList = date.getItemList();
                break;
            }
        }

        List<Item> orderItemList = request.getItems();
        List<Category> updatedCategoryList = new ArrayList<>();
        for(Category ct:categoryList) {
            updatedCategoryList.add(ct.clone());
        }

        for(int i=0;i<orderItemList.size();i++){
            Item orderItem = orderItemList.get(i);
            String orderItemCategoty = orderItem.getCategory();
            int categoryLimit = Integer.MAX_VALUE;
            Category orderCategory = null;

            for(int j=0;j<updatedCategoryList.size();j++){
                if(updatedCategoryList.get(j).getName().equals(orderItemCategoty)){
                    orderCategory = updatedCategoryList.get(j);
                    categoryLimit = (updatedCategoryList.get(j).getCategoryLimit().get(orderDate) == null ? Integer.MAX_VALUE : updatedCategoryList.get(j).getCategoryLimit().get(orderDate));
                    break;
                }
            }

            boolean isThisItemPresentInWareHouse = false;
            for(int j=0;j<itemList.size();j++){
                Item item = itemList.get(i);
                if(orderItem.getItem_name().equals(item.getItem_name())){
                    isThisItemPresentInWareHouse = true;
                    if(!(orderItem.getQuantity() <= item.getQuantity() && orderItem.getQuantity()<= categoryLimit)) {
                        return false;
                    }
                    if(orderCategory != null && orderCategory.getCategoryLimit().get(orderDate) != null) {
                        orderCategory.getCategoryLimit().put(orderDate, categoryLimit-orderItem.getQuantity());
                    }
                }
            }
            if(!isThisItemPresentInWareHouse) return false;

        }

        return true;
    }


}