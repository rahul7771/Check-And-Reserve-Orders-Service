package com.example.demo.service;

import com.example.demo.db.CategoryDB;
import com.example.demo.db.WarehouseDB;
import com.example.demo.exchange.Request;
import com.example.demo.model.Category;
import com.example.demo.model.Item;
import com.example.demo.model.OrderDate;
import com.example.demo.model.WareHouse;
import com.example.demo.utils.InializeDbHelper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReserveOrder {
    CategoryDB categoryDB;

    WarehouseDB warehouseDB;

    public Boolean ReserveOrderService(Request request, CategoryDB categoryDB, WarehouseDB warehouseDB) throws InterruptedException {
        this.warehouseDB = warehouseDB;
        this.categoryDB = categoryDB;
        List<WareHouse> wareHouseList = warehouseDB.getWareHouseList();
        List<Category> categoryList = categoryDB.getCategoryList();

        WareHouse wareHouse = new WareHouse();
        for(int i=0;i<wareHouseList.size();i++){
            if(wareHouseList.get(i).getId().equals(request.getWarehouse_id())) {
                wareHouse = wareHouseList.get(i);
                break;
            }
        }

        LocalDate orderDate = request.getDelivery_date();
        List<Item> itemList = new ArrayList<>();

        for(int i=0;i<wareHouse.getDates().size();i++){

            OrderDate date = wareHouse.getDates().get(i);

            if(date.getDate().equals(orderDate)) {
                itemList = date.getItemList();
                break;
            }
        }

        List<Item> orderItemList = request.getItems();
        List<Item> updatedItemList = new ArrayList<>();
        List<Category> updatedCategoryList = new ArrayList<>();

        for(Item it:itemList) {
            updatedItemList.add(it.clone());
        }
        for(Category ct:categoryList) {
            updatedCategoryList.add(ct.clone());
        }

        for(int i=0;i<orderItemList.size();i++){
            Item orderItem = orderItemList.get(i);
            String orderItemCategoty = orderItem.getCategory();
            int categoryLimit = Integer.MAX_VALUE;
            Category orderCategory = null;

            for(int j=0;j<updatedCategoryList.size();j++){
                if(updatedCategoryList.get(j).getName().equals(orderItemCategoty)){
                    orderCategory = updatedCategoryList.get(j);
                    categoryLimit = (updatedCategoryList.get(j).getCategoryLimit().get(orderDate) == null ? Integer.MAX_VALUE : updatedCategoryList.get(j).getCategoryLimit().get(orderDate));
                    break;
                }

            }

            boolean isThisItemPresentInWareHouse = false;
            for(int j=0;j<updatedItemList.size();j++){
                Item item = updatedItemList.get(j);
                if(orderItem.getItem_name().equals(item.getItem_name())){
                    isThisItemPresentInWareHouse = true;
                    if(!(orderItem.getQuantity() <= item.getQuantity() && orderItem.getQuantity()<= categoryLimit)) {
                        return false;
                    }
                    item.setQuantity(item.getQuantity()-orderItem.getQuantity());
                    if(orderCategory != null && orderCategory.getCategoryLimit().get(orderDate) != null) {
                        orderCategory.getCategoryLimit().put(orderDate, categoryLimit-orderItem.getQuantity());
                    }
                }
            }
            if(!isThisItemPresentInWareHouse) return false;
        }


        for(int i=0;i<wareHouse.getDates().size();i++){

            OrderDate date = wareHouse.getDates().get(i);

            if(date.getDate().equals(orderDate)) {
//                List<Item> items = date.getItemList();
                date.setItemList(updatedItemList);
//                for(int j=0;j<items.size();j++){
//                    for(int k=0;k<updatedItemList.size();k++){
//                        if(items.get(j).getItem_name().equals(updatedItemList.get(k).getItem_name())){
//                            items.get(j).setQuantity(updatedItemList.get(k).getQuantity());
//                            break;
//                        }
//                    }
//                }
                break;
            }
        }

        categoryDB.setCategoryList(updatedCategoryList);

        return true;
    }
}
