package com.example.demo.exchange;

import lombok.Data;

@Data
public class CanFulfillResponse {
    String can_fulfil;
}
