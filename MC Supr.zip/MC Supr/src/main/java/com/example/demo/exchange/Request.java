package com.example.demo.exchange;

import com.example.demo.model.Item;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Request {
    String customer_id; // Customer ID
    String warehouse_id; // ID of Warehouse which serves the Customer
    LocalDate delivery_date; // Delivery Date
    List<Item> items; // Items that Customer is trying to Order
}