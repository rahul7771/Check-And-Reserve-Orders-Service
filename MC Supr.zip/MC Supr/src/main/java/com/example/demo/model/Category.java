package com.example.demo.model;

import lombok.Data;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Data
public class Category implements Cloneable{
    String name;
    Map<LocalDate, Integer> categoryLimit;
    @Override
    public Category clone() {
        Category clonedCategory = null;
        try {
            clonedCategory = (Category) super.clone();
            Map<LocalDate, Integer> newCategoryLimit = new HashMap<>();
            Iterator<Map.Entry<LocalDate, Integer>> itr = categoryLimit.entrySet().iterator();

            while(itr.hasNext()) {
                Map.Entry<LocalDate, Integer> entry = itr.next();
                newCategoryLimit.put(entry.getKey(), entry.getValue());
            }
            clonedCategory.setCategoryLimit(newCategoryLimit);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return clonedCategory;
    }
}
