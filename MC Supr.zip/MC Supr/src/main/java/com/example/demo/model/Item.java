package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
public class Item implements Cloneable{
    String item_name;
    Integer quantity;
    String category;
    @Override
    public Item clone() {
        Item clonedItem = null;
        try {
            clonedItem = (Item) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return clonedItem;
    }
}
