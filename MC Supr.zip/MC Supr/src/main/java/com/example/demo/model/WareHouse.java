package com.example.demo.model;

import lombok.Data;

import java.util.List;

@Data
public class WareHouse {
    String id;
    List<OrderDate> dates;
}
