package com.example.demo.controller;

import com.example.demo.db.CategoryDB;
import com.example.demo.db.WarehouseDB;
import com.example.demo.exchange.Request;
import com.example.demo.exchange.CanFulfillResponse;
import com.example.demo.exchange.ReserveOrderResponse;
import com.example.demo.exchange.ReserveOrderResponseData;
import com.example.demo.service.CanFulfilOrder;
import com.example.demo.service.ReserveOrder;
import com.example.demo.utils.InializeDbHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping
@Controller
public class MainController {
    @Autowired
    CanFulfilOrder canFulfilOrder;

    @Autowired
    ReserveOrder reserveOrder;

    CategoryDB categoryDB;

    WarehouseDB warehouseDB;

    MainController() {
        categoryDB = InializeDbHelper.initializeCategoryDB();
        warehouseDB = InializeDbHelper.initializeWarehouseDB();
    }


    @PostMapping("/fulfill")
        public ResponseEntity<CanFulfillResponse> canFulfilOrder(@RequestBody Request request) throws InterruptedException {
        System.out.println("fulfill !! ");
        Boolean result = canFulfilOrder.OrderFulfilmentService(request, categoryDB, warehouseDB);
        CanFulfillResponse canFulfillResponse = new CanFulfillResponse();

        if(result) {
            canFulfillResponse.setCan_fulfil("true");
        }else{
            canFulfillResponse.setCan_fulfil("false");
        }

        return ResponseEntity.ok().body(canFulfillResponse);
    }

    @PostMapping("/reserve")
    public ResponseEntity<ReserveOrderResponse> reserveOrder(@RequestBody Request request) throws InterruptedException {
        System.out.println("reserve !! ");
        Boolean result = reserveOrder.ReserveOrderService(request, categoryDB, warehouseDB);
        ReserveOrderResponse reserveOrderResponse = new ReserveOrderResponse();

        reserveOrderResponse.setCode("Success");
        if(result) {
            reserveOrderResponse.setData(new ReserveOrderResponseData(true, "Success"));
        }else{
            reserveOrderResponse.setData(new ReserveOrderResponseData(false, "Insufficient quantities!"));
        }

        return ResponseEntity.ok().body(reserveOrderResponse);
    }
}

