package com.example.demo.utils;

import com.example.demo.db.CategoryDB;
import com.example.demo.db.WarehouseDB;
import com.example.demo.model.Category;
import com.example.demo.model.Item;
import com.example.demo.model.OrderDate;
import com.example.demo.model.WareHouse;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InializeDbHelper {
    public static CategoryDB initializeCategoryDB() {
        CategoryDB categoryDB = new CategoryDB();



        Map<LocalDate, Integer> categoryLimit = new HashMap<>();
        categoryLimit.put(LocalDate.of(2020,10,15), 150);
        categoryLimit.put(LocalDate.of(2020,10,16), 50);

        Category category1 = new Category();
        category1.setName("F_N_V");
        category1.setCategoryLimit(categoryLimit);

        List<Category> categoryList = new ArrayList<>();
        categoryList.add(category1);

        categoryDB.setCategoryList(categoryList);
        return categoryDB;
    }

    public static WarehouseDB initializeWarehouseDB() {
        WarehouseDB warehouseDB = new WarehouseDB();

        List<WareHouse> wareHouseList = new ArrayList<>();

        Item i1 = new Item("i1",100,"F_N_V");
        Item i2 = new Item("i2",300,"Grocery");
        List<Item> itemList =new ArrayList<>();
        itemList.add(i1);
        itemList.add(i2);

        OrderDate orderDate1 = new OrderDate();
        orderDate1.setDate(LocalDate.of(2020,10,15));
        orderDate1.setItemList(itemList);

        Item i3 = new Item("i1",200,"F_N_V");
        Item i4 = new Item("i2",400,"Grocery");
        List<Item> itemList2 =new ArrayList<>();
        itemList2.add(i3);
        itemList2.add(i4);
        OrderDate orderDate2 = new OrderDate();
        orderDate2.setDate(LocalDate.of(2020,10,16));
        orderDate2.setItemList(itemList2);

        List<OrderDate> dates = new ArrayList<>();
        dates.add(orderDate1);
        dates.add(orderDate2);

        WareHouse firstWareHouse = new WareHouse();
        firstWareHouse.setId("100");
        firstWareHouse.setDates(dates);

        wareHouseList.add(firstWareHouse);

        warehouseDB.setWareHouseList(wareHouseList);
        return warehouseDB;
    }
}
